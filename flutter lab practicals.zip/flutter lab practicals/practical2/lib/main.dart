import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    //title: "flutter application",
    home: Scaffold(
      appBar: AppBar(
        title: Text("This is my application"),
        ),
        body: Text("This is my application body"
        ),
    ),
  ));
}

